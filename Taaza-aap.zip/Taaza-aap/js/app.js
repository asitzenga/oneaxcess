var MyApp = angular.module('MyApp', []);
MyApp.controller('ssl-ctrl', function ($scope) {
	$scope.showPopup = false;
	$scope.errorMessage = false;

	$scope.isPopupVisble = function () {
		$scope.showPopup = true;
	};
	$scope.hidePrompt = function () {

		$scope.showPopup = false;
	};
	$scope.hidePrompt();

});

